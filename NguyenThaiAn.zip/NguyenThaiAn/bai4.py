diem = float(input("nhập điểm của học sinh: "))
if diem >= 8.5:
    print("xếp hạng A")
elif diem >= 7:
    print("xếp hạng B")
elif diem >= 5:
    print("xếp hạng C")
else:
    print("xếp hạng D")