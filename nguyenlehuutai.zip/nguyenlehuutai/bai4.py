n= float(input("Nhap so diem cua hoc sinh:"))
if n> 8.5:
    print("Xep hang A")
elif n> 7:
    print("Xep hang B")
elif n> 5:
    print("Xep hang c")
else:
    print("Xep hang d")