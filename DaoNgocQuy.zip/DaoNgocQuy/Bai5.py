can_nang = float(input("Nhap can nang: "))
chieu_cao = float(input("NHap chieu cao: "))
BMI = can_nang / (chieu_cao**2)
if BMI < 18.5:
    print("Gay")
if 18.5 <= BMI <= 24.9:
    print("Binh thuong.")
if 25 <= BMI <= 29.9:
    print("Thua can.")
if 30 <= BMI:
    print("Beo phi.")