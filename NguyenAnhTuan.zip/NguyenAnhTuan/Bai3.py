print("Bài 3:")
tuoi = int(input("Nhập vào số số tuổi của 1 người: "))
if tuoi < 12:
    print ("Trẻ em")
elif tuoi <= 17:
    print ("Thiếu niên")
elif tuoi <= 59:
    print ("Người trưởng thành")
else:
    print ("Người cao tuổi")