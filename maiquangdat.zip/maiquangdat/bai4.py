d = float(input("nhap diem: "))
if d >= 8.5:
    print("hang A")
elif d >= 7:
    print("hang B")
elif d >= 5.5:
    print("hang C")
else:
    print("hang D")