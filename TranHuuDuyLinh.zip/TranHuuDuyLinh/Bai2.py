N = int(input("Nhập năm dương lịch : "))

if (N % 400 == 0) or ( N % 4 == 0 and N % 100 != 0):
    print(N, "Là năm nhuận")
else:
    print(N, "không phải là năm nhuận")