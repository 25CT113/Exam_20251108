tuoi = int(input("nhập tuổi của bạn: "))
if tuoi < 12:
    print("bạn là trẻ em")
elif tuoi <= 17:
    print("bạn là 1 thiếu niên")
elif tuoi <= 59:
    print("bạn là người trưởng thành")
else:
    print("bạn là người cao tuổi")