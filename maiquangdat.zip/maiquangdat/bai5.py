cn = float(input("can nang (kg): "))
cc = float(input("chieu cao (m): "))
bmi = cn / (cc ** 2)
print("bmi =", round(bmi, 1))
if bmi < 18.5:
    print("gay")
elif bmi < 25:
    print("binh thuong")
elif bmi < 30:
    print("thua can")
else:
    print("beo phi")