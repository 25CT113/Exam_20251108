N= int(input("Nhap so tuoi:"))
if N<= 12:
    print("tre em")
elif N<= 59:
    print("thieu nien")
else:
    print("Nguoi cao tuoi")