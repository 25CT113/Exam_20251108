#Kiem tra tuoi cua 1 nguoi
# Nhap tuoi cua 1 nguoi
N = int(input("Nhap tuoi cua mot nguoi: "))
# Kiem tra tuoi
if N < 12:
    print(" Tre em")
elif N <=17:
    print("Thieu nien")
elif N <= 59:
    print("Nguoi truong thanh")
else:
    print("Nguoi cao tuoi")