print("Bài 4:")
diem = float(input("Nhập vào điểm số của học sinh: "))
if diem >= 8.5:
    print ("Hạng A")
elif diem >= 7:
    print ("Hạng B")
elif diem >= 5:
    print ("Hạng C")
else:
    print ("Hạng D")