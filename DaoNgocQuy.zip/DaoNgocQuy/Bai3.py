N = int(input("Nhap tuoi cua 1 nguoi: "))
if N < 12:
    print(f"Trẻ em.")
if 12 <= N <= 17:
    print(f"Thiếu niên.")
if 18 <= N <= 59:
    print(f"Người trưởng thành.")
if 60 <= N:
    print(f"Người cao tuổi.")