
kg = float(input("Cân nặng: "))
m = float(input("Chiều cao: "))

n = kg / m ** 2
if n < 0:
    print("BMI không hợp lệ!")
elif n < 18.5:
    print("Gầy!")
elif n < 25:
    print("Bình thường!")
elif n < 30:
    print("Thừa cân!")
else:
    print("Béo phì!")