# Nhap so Kw dien da su dung
try:
    Kw_su_dung = int(input("nhap so Kw dien da su dung trong thang (so nguyen duong): "))
    if  Kw_su_dung < 0:
        print("so Kw phai la so khong am.")
        exit()
except ValueError:
    print("Dau vao khong hop le. Vui long nhap mot so nguyen.")
    exit()

# Dinh nghia bang cac hang so don gia
GIA_BAC_1 = 2000 # 1-100 Kw
GIA_BAC_2 = 3000 # 101-200 Kw
GIA_BAC_3 = 4000 # 201 Kw tro len

tong_tien = 0

# --- Xu ly tinh tien theo tung bac thang ---

# Bac 1: Tu 1 den 100Kw
if Kw_su_dung > 0:
    KW_bac_1 = min(Kw_su_dung, 100) # So Kw tinh theo bac 1 (toi da 100)
    tien_bac_1 = Kw_bac_1 * GIA_BAC_1
    tong_tien += tien_bac_1
    Kw_con_lai = Kw_su_dung - Kw_bac_1
    print(f" > Bac 1 (toi da 100 Kw): {Kw_bac_1} Kw * {GIA_BAC_1} d = {tien_bac_1} d")

# Bac 2: Tu 101 den 200Kw
if Kw_con_lai > 0:
    Kw_bac_2 = min(Kw_con_lai, 100) # So Kw tinh theo bac 2 (toi da 100)
    tien_bac_2 = Kw_bac_2 * GIA_BAC_2
    tong_tien += tien_bac_2
    Kw_con_lai -= Kw_bac_2
    print(f" > bac 2 (101-200 Kw): {Kw_bac_2} Kw * {GIA_BAC_2} d = {tien_bac_2} d")
# Bac 3: Tu 201 Kw tro len
if Kw_con_lai > 0:
    Kw_bac_3 = Kw_con_lai # So Kw con lai tinh het theo bac 3
    tien_bac_3 = Kw_bac_3 * GIA_BAC_3
    tong_tien += tien_bac_3
    print(f" > Bac 3 (tu 201 Kw): {Kw_bac_3} Kw * {GIA_BAC_3} d = {tien_bac_3} d")
# In ra ket qua cuoi cung
print("-" * 30)
print(f"Tong so Kw da su dung): {Kw_su_dung} Kw")
print(f"Tong so tien dien phai tra: {tong_tien:,.0f} d")