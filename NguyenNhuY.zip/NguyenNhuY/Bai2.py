N = int(input("Nhập số Kw điện đã sử dụng"))
if N <= 100:
    tien = N * 2000
elif N <= 200:
    tien = 100 * 2000 + (N - 100) * 3000
else:
    tien = 100 * 2000 + 100 * 3000 + (N - 200) * 40000
print(f"Số tiền điện phải trả là: {tien:.0f} đồng")