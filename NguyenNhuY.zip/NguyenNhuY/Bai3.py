N = int(input("Hãy nhập số tuổi: "))
if N < 12:
    print("Trẻ con")
elif N <= 17:
    print("Thiếu niên")
elif N <= 59:
    print("Người trưởng thành")
else:
    print("Người cao tuôỉ")