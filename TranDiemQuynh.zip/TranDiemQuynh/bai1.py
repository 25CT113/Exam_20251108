x1 = int(input("Nhập số thứ nhất: "))
x2 = int(input("Nhập số thứ hai: "))
x3 = int(input("Nhập số thứ ba: "))

nho_nhat = min(x1, x2, x3)
print("số nhỏ nhất là:", nho_nhat)