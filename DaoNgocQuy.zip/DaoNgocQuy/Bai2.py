N = int(input("Nhap so nguyen tuong ung voi so Kw dien da su dung: "))
if N <= 100:
    tien = N * 2000
elif N <= 200:
    tien = 100 * 2000 + (N - 100) * 3000
else:
    tien = 100 * 2000 + 100 * 3000 + (N - 200) * 4000
    print(f"tiền điện phải trả là: {tien}đ")