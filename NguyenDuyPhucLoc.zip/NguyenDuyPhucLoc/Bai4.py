#Nhap 2 lan mat khau moi:
mk1=input('Nhap mat khau moi: ')
mk2=input('Nhap xac nhan mat khau moi lan 2: ')
#Kiem tra xem co giong nhau khonng
if mk1 != mk2:
    print('Mat khau khong giong nhau roi.')
else:
    print('Mat khau da duoc doi thanh cong.')