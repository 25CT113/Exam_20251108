Kw = int(input("Nhập số Kw điện đã sử dung trong tháng: "))
if Kw <= 100:
    tien = Kw * 2000
elif Kw <= 200:
    tien = Kw * 3000
else:
    tien = Kw * 4000
print("Số tiền phải trả là: ", tien)
