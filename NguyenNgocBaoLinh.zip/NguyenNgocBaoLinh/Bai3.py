temp = float(input("Giá trị nhiệt độ:"))
if temp>30:
    print("Trời đang nóng")
elif temp<20:
    print("Trời đang lạnh")
else:
    print("Thời tiết dễ chịu")