nhiet_do = float(input("nhập nhiệt độ hiện tại: "))

if nhiet_do < 20:
    print("trời đang lạnh")
else:
    print("trời đang ấm nóng")