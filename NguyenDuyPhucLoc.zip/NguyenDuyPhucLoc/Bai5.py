#Nhap so km da di duoc
so_kilomet=float(input('Nhap so kilomet da di: '))
#Xac dinh dieu kien
if so_kilomet <= 1:
    tien= so_kilomet*7000
elif so_kilomet <= 5:
    tien= 7000+(so_kilomet-1)*6500
else:
    tien=7000+4*6500+(so_kilomet-5)*6000
#Xuat ket qua
print(f'So tien phai tra la: {tien:,.0f} dong')