# Xep hang A,B,C,D cho hoc sinh
N = int(input(" Nhap diem so cua hoc sinh: "))
# Kiem tra diem
if N >= 8.5:
    print("xep hang A")
elif N >= 7:
    print ("xep hang B")
elif N >= 5:
    print("xep hang C")
else:
    print(" xep hang D")