N= int(input("Nhap so nguyen n:"))
if N > 0:
    print("N la so duong")
elif N < 0:
    print("N la so duong")
else:
    print("N la so 0")