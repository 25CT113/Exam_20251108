km = float(input("nhập số km đã đi: "))
tien = 0

if km <= 1:
    tien = km * 7000
elif km <= 5:
    tiên = 1 * 7000 + (km - 1) * 6500
else:
    tien = 1 * 7000 + 4 * 6500 + (km - 5) * 6000
print("số tiền phải trả là:", tien, "đồng")