n = int(input("Nhap so nguyen N: "))
if n > 0:
    print("N là 1 số nguyên dương")
elif n < 0:
    print("N là 1 số nguyên âm")
else:
    print("N là số 0")
