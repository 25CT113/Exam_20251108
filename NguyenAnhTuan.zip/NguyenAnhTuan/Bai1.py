print("Bài 1:")
N = int(input("Nhập 1 số nguyên N: "))
if N < 0:
    print("N là số âm")
elif N > 0:
    print("N là số dương")
else:
    print("N là số 0")

