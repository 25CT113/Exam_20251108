mk1 = input("Bạn hãy nhập mật khẩu mới: ")
mk2 = input("Bạn hãy xác nhận mật khẩu mới lần 2: ")

if mk1 == mk2:
    print("Mật khẩu được đổi thành công")
else:
    print("Mật khẩu không giống nhau rồi")    