N = int(input("nhap so kw dien da su dung : "))
if N <= 100:
    tien = N*2000
if N <= 200:
    tien = 100 * 2000 + 100 * 3000 + (N-200) * 4000
else:
    tien = 100 * 2000 + 100 * 3000 + (N-200) * 4000
print("tien dien phai tra la :", tien, "dong")

