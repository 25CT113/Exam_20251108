#Nhap nhiet do hien tai
nhiet_do=float(input('Nhap nhiet do: '))
#Kiem tra dieu kien
if nhiet_do >30:
    print('Troi dang nong.')
elif nhiet_do <20:
    print('Troi dang lanh.')
else:
    print('Thoi tiet de chiu.')
