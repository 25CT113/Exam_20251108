n = int(input("Số Kw: "))
if n <= 100:
    print("2000đ/Kw")
elif n <= 200:
    print("3000đ/Kw")
else:
    print("4000đ/Kw")