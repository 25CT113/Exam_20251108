km = float(input("Số km đã đi của xe taxi: "))
if km<=0:
    print("Quãng đường không hợp lệ!")
elif km<=1:
    tien = km*7000
elif km<=5:
    tien = 7000+(km-1)*6500
else:
    tien = 7000+4*6500+(km-5)*6000
print(f"Tiền phải trả: {tien:,.0f}đ")