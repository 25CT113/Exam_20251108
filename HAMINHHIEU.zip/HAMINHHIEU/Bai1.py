# nhap so nguyen tu nguoi dung
try:
 N = int(input("Nhap mot so nguyen N: "))
except ValueError:
 print("Dau vao khong hop le. Vui long nhap mot so nguyen.")
 exit()
# kiem tra va in ra loai so cua N
if N > 0:
 print(f"so {N} la so duong.")
elif N < 0:
 print(f"so {N} la so am.")
else:
# N == 0
 print(f"so {N} la so 0.")