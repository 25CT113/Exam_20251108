n = int(input("Tuổi: "))
if n < 1:
    print("Tuổi không hợp lệ!")
elif n < 12:
    print("Trẻ em")
elif n <= 17:
    print("Thiếu niên")
elif n <= 59:
    print("Người trưởng thành")
else:
    print("Người cao tuổi")