N = int(input("Nhap so kw da su dung trong thang:"))
if N<= 100:
    tien= N*2000
elif N<= 200:
    tien= 100*2000+(N-100)*3000
else:
    tien= 100*2000+100*3000+(N-200)*4000
    print("Tien dien phai tra la.",tien,"dong")