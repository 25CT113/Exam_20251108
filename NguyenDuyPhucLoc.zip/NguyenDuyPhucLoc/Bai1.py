#Nhap vao 3 so nguyen x1, x2, x3
x1=int(input('Nhap so dau tien: '))
x2=int(input('Nhap so thu hai: '))
x3=int(input('Nhap so thu ba: '))
#Tim so nho nhat trong 3 so
nho_nhat=min(x1,x2,x3)
#Xuat ket qua
print('So nho nhat la: ',nho_nhat)
