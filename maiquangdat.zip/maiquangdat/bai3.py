tuoi = int(input("nhap tuoi: "))
if tuoi < 12:
    print("tre em")
elif tuoi <= 17:
    print("thieu nien")
elif tuoi <=59:
    print("nguoi truong thanh")
else:
    print("nguoi cao tuoi")
