can_nang= float(input("Nhap can nang (kg):"))
chieu_cao= float(input("Nhap chieu cao (m):"))
BMI= can_nang/(chieu_cao**2)
print("Chi so BMI cau ban la:",round(BMI,2))
if BMI< 18.5:
    print("Ban thuoc nhom: gay")
elif BMI< 25:
    print("Ban thuoc nhom nguoi: binh thuong")
elif BMI>= 30:
    print("Ban thuoc nhom nguoi: beo phi")