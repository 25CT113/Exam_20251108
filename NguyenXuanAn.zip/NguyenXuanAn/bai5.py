# Tinh BMI
chieu cao = int(input("Nhap can nang: "))
N = float(input("Nhap chieu cao: "))
# BMI = cang nang / chieu cao **2)
if BMI < 18.5:
    print("gay")
elif BMI < 25:
    print("binh thuong")
elif BMI < 30:
    print("thua can")
else:
    print("beo phi")
print("ket qua BMI: ")
