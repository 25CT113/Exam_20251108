print("Bài 5:")
cannang = float(input("Nhập cân nặng: "))
chieucao = float(input("Nhập chiêu cao: "))
BMI = cannang / (chieucao ** 2)
print(f"Chỉ số BMI = {BMI:.2f}")

if BMI < 18.5:
    print ("Gầy")
elif BMI < 25:
    print ("Bình thường")
elif BMI < 30:
    print ("Thừa cân")
else:
    print ("Béo phì")