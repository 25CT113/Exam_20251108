N = int(input("Nhập giá trị nhiệt độ: "))

if N > 30:
    print("Trời đang nóng")
elif N < 20:
    print("Trời đang lạnh")
else:
    print("Thời tiết dễ chịu")