N = float(input("Nhập số điểm của học sinh"))
if N >= 8.5:
    print("Xếp hạng A")
elif N >7:
    print("Xếp hạng B")
elif N >= 5:
    print("Xếp hạng C")
else:
    print("Xếp hạng D")