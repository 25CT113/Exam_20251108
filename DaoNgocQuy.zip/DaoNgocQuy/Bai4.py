D = float(input("Nhap diem so cua hoc sinh: "))
if 8.5 <= D <= 10:
    print("Xep hang A.")
if 7 <= D < 8.5:
    print("Xep hang B.")
if 5 <= D < 7:
    print("Xep hang C.")
if D < 5:
    print("Xep hang D.")