import math
cannang = float(input("nhập cân nặng của bạn:"))
chieucao = float(input("nhập chiều cao của bạn:"))
BMI = cannang / chieucao ** 2
if BMI < 18.5:
    print("gầy")
elif BMI <= 24.9:
    print("bình thường")
elif BMI <= 29.9:
    print("thừa cân")
else:
    print("béo phì")
