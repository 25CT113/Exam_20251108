N = int(input(f"nhập một số nguyên N: "))
if N > 0:
    print (f"N là số dương.")
if N < 0:
    print (f"N là số âm.")
if N == 0:
    print (f"N là số 0.")
    