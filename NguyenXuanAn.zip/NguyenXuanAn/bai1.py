# kiem tra loai so
# Nhap 1 so nguyen N
N = int(input("Nhap mot so nguyen N: "))
#Kiem tra va in ket qua
if N > 0:
    print("N la so duong")
elif N < 0:
    print("N la so am")
else:
    print("N la so 0 ")