x1 = int(input("Nhập số nguyên X1: "))
x2 = int(input("Nhập số nguyên X2: "))
x3 = int(input("Nhập số nguyên X3: "))

nho_nhat = min(x1, x2, x3)
print("Số nhỏ nhất là:", nho_nhat)