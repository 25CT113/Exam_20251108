n = float(input("Điểm số: "))
if n < 0:
    print("Điểm không hợp lệ!")
elif n < 5:
    print("Xếp hạng D!")
elif n < 7:
    print("Xếp hạng C!")
elif n < 8.5:
    print("Xếp hạng B!")
elif n < 11:
    print("Xếp hạng A!")
else:
    print("Điểm không hợp lệ!")