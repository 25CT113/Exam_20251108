print("Bài 2:")
so_kw = int(input("Nhập vào số Kw điện đã sử dụng trong tháng: "))
if so_kw <= 100:
    tien = so_kw * 2000
elif so_kw <= 200:
    tien = 100 * 2000 + (so_kw - 100) * 3000
else:
    tien = 100 * 2000 + 100 * 3000 + (so_kw - 200) * 4000
print(f"Số tiền điện phải trả là: {tien} đồng")