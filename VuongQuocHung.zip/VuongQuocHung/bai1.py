n = int(input("N la so: "))
if n > 0:
    print(f"{n} la so duong!")
elif n < 0:
    print(f"{n} la so am!")
else:
    print(f"{n} la so 0!")