mk1 = input("bạn hãy nhập mật khẩu: ")
mk2 = input("nhập lại mật khẩu lần 2: ")
if mk1 == mk2:
     print("đặt mật khẩu thành công")
else:
     print("mật khẩu không giống nhau")