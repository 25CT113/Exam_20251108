n= int(input("nhap so N: "))
if n > 0:
    print("N la so duong")
elif n < 0:
    print("N la so am")
else:
    (print ("N la so 0"))
