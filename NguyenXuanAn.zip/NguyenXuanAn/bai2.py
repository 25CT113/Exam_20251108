# Tien dien phai tra cua thang:
kw = int(input("Nhap so kw dien da su dung trong thang: "))
# Tinh tien dien theo bang
if kw <= 100:
    tien = kw * 2000
elif kw <= 200 :
    tien = 100 * 2000 + (kw - 100) * 3000
else :
    tien = 100 * 2000 + 100 * 3000 + (kw - 200) * 4000
print("So tien dien phai tra cua thang la:", tien, " dong")